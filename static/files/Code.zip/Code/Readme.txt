

Replication Files for Data Science in Stata 16: Frames, Lasso, and Python Integration

Authors:  Ho, Huynh, Jacho and Rojas, 2020 

This are the instructions for the replication files for the article.

There are two files that are used for the article: jssscatterplot.do and
testjss.py.

The first is a Stata Do file that produces a scatter plot using matplotlib. To run this script you will need an Stata 16 license.

The second one is testjss.py which is a file that produces a contour plot. This scriptis used to illustrate how to run a python script from Stata.

Please read the instructions on each of the files headers.


