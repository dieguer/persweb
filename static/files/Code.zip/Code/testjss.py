# File name: testjss.py

#############################################################
# REPLICATION CODE FOR SECTION ON PYTHON INTEGRATION 
#       Copyright 2020 Ho, Huynh, Jacho and Rojas
# Author: Ho, Huynh, Jacho and Rojas
# Purpose: Illustrate the posibility of running python scripts from Stata16
#
# Important: To run this code user must possess a licence of
#      Stata 16. You need to have local installation of Python 3.
# Also,  all required modules should be 
#      should be installed in your local Python installation.
#
# Windows users: To run this code with a Anaconda installation 
# you need to make sure that the QT-plugin is correctly 
# linked by typing on your Stata command prompt
#     
#       python
#       import os
#       os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = #"Your\\path\\to\\Anaconda3\\Library\\plugins"
#       end
#
#############################################################



# change path to your anaconda 
import os
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = "C:\\Users\\diego\\Anaconda3\\Library\\plugins"
 


import matplotlib.pyplot as plt
from matplotlib import style
style.use('fivethirtyeight')
import numpy as np
from scipy.stats import multivariate_normal

def plot_norm(M,Cov,n):
    rv = multivariate_normal(M, Cov, n)
    x = np.linspace(-10, 10, 500)
    y = np.linspace(-10, 10, 500)
    X, Y = np.meshgrid(x, y)
    pos = np.array([X.flatten(), Y.flatten()]).T
    fig = plt.figure(figsize=(5, 5))
    ax0 = fig.add_subplot(111)
    ax0.contour(rv.pdf(pos).reshape(500, 500))
    plt.show()

mean = [0, 0]
cov = [[7, 0.7], [0.7, 11]]  

plot_norm(mean, cov, 300)


 #   This program is free software: you can redistribute it and/or modify
 #   it under the terms of the GNU General Public License as published by
 #   the Free Software Foundation, either version 3 of the License, or
 #   (at your option) any later version.

 #   This program is distributed in the hope that it will be useful,
 #   but WITHOUT ANY WARRANTY; without even the implied warranty of
 #   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #   GNU General Public License for more details.

 #  You should have received a copy of the GNU General Public License
 #   along with this program.  If not, see <https://www.gnu.org/licenses/>.
